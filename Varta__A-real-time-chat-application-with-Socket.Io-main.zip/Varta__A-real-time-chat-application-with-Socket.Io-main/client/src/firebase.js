import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDm8u04v2sIRFgPQNzkYa2rCoM2m9BAmAU",
  authDomain: "varta-the-chat-app.firebaseapp.com",
  databaseURL: "https://varta-the-chat-app-default-rtdb.firebaseio.com",
  projectId: "varta-the-chat-app",
  storageBucket: "varta-the-chat-app.appspot.com",
  messagingSenderId: "132806365696",
  appId: "1:132806365696:web:5f182adf0ca85eb649fee5"
};  

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore()
